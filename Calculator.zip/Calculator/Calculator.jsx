import React, { useState } from "react";

function HelloWorld() {
  return <h1>Hello, world!</h1>;
}

function Counter() {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  const handleDecrement = () => {
    setCount(count - 1);
  };

  return (
    <div>
      <button onClick={handleIncrement}>+</button>
      <label>{count}</label>
      <button onClick={handleDecrement}>-</button>
    </div>
  );
}

export default HelloWorld;

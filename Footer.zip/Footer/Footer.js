
import './Footer.css';
import React from 'react';
import fb from '../assets/fb.png'
import link1 from '../assets/link1.png'
import twiter from '../assets/twiter.png'
import insta from '../assets/insta.png'
function Footer() {
return (

  <div className="footer">
  <div className="sb_footer section_padding">
    <div className="sb_footer-links">

    <div className="sb_footer-links_div">
      <h4><b>Ramada</b></h4>
      <a href="/about"></a>
          <p>press</p>
          <a href="/career"></a>
          <p> Career</p>
          <a href="/contact"></a>
          <p>Contacts</p>
      </div>
      
      <div className="sb_footer-links_div">
      <h4><b>Resources</b></h4>
      <a href="/employer"></a>
          <p> Employer</p>
          <a href="/healthplan"></a>
          <p> Health Plan</p>
          <a href="/indiviuals"></a>
          <p>indiviuals</p>
      </div>
      <div className="sb_footer-links_div">
      <h4><b>Partner</b></h4>
      <a href="/employer"></a>
      <p>Pearl Continetal</p>
      </div>
      <div className="sb_footer-links_div">
        
        <h4><b>Forbussiness</b></h4>
          <a href="/employer"></a>
          <p> Employer</p>
          <a href="/healthplan"></a>
          <p> Health Plan</p>
          <a href="/indiviuals"></a>
          <p>indiviuals</p>
      </div>
      <div className="sb_footer-links_div">
            
        <div className="social-media">
       <p> <img src ={fb} alt =""/></p>
       <p> <img src ={link1} alt =""/></p>
       <p> <img src ={twiter} alt =""/></p>
       <p> <img src ={insta} alt =""/></p>
         
        </div>
        <h4>Feedback Website</h4>
      </div>
      </div>
    
      <hr/>
      
      <div className="sb_footer-below">
      <div className="sb_footer-copyright">
        <p> Hotel All right reserved.</p>
       </div>

      <div className="sb_footer-below-links">
      <a href="/terms"><div><p>Term & Conditions</p></div></a>
      <a href="/privacy"><div><p>Privacy</p></div></a>
      <a href="/security"><div> <p>Security</p></div></a>
       <a href="/cookie"><div><p>Cookie declaration</p></div></a>
    </div>
    </div>
    </div>
    </div>
);
}

export default Footer;

import React from "react";
import card from '../assets/card.png'
import './Payment.css';


function Payment() {
    return (
        <div className="container">
            <form action="form">
            <div className="row">
           <div className="col">
           <h3 className="title">Billing Address</h3>
           <div className="inputbox">
            <span> Full Name:</span>
            <input type ="text" placeholder="john deo"/> 
        </div>

        <div className="inputbox">
            <span> email:</span>
            <input type ="email" placeholder="example@example.com"/> 
        </div>

        <div className="inputbox">
            <span> address:</span>
            <input type ="email" placeholder="room- street-locality"/> 
        </div>
        <div className="inputbox">
            <span> city:</span>
            <input type ="email" placeholder="mubai"/> 
        </div>
        <div className="flex">
        <div className="inputbox">
            <span> state:</span>
            <input type ="email" placeholder="india"/> 


        <div className="inputbox">
            <span> zip code:</span>
            <input type ="email" placeholder="123 456"/> 
        </div>
        </div>
        </div>

        <div className="col">
        <div className="inputbox">
            <span>  card accepted :</span>
            <div className="image">
            <p> <img src ={card} alt =""/></p>
            </div>
            <div className="inputbox">
            <span> name of cards:</span>
            <input type ="text" placeholder="mr.john deo"/> 
        </div>

        <div className="inputbox">
            <span> credit card number :</span>
            <input type ="number" placeholder="1111-2222-5555"/> 
        </div>
        <div className="inputbox">
            <span> exp month:</span>
            <input type ="email" placeholder="march"/> 
        </div>
        <div className="inputbox">
            <span> exp year</span>
            <input type ="number" placeholder="2022"/> 
        </div>
        <div className="flex">
        <div className="inputbox">
            <span> CCV:</span>
            <input type ="email" placeholder="1234"/> 
        </div>
        </div>
        </div>
        </div>
            </div>
            </div>
            <input type="submit" value="proceed to checkout" className="submit-btn"/>
            </form>

            </div>
    );
  }
  
  export default Payment;
  
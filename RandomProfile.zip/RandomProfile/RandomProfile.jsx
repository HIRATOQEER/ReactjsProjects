import React, { useState } from "react";
import './Rand.css'
import $ from "jquery";

function RandomProfile() {
  const [userProfile, setUserProfile] = useState({});

  const fetchRandomProfile = () => {
    $.ajax({
      url: "https://randomuser.me/api/",
      dataType: "json",
      success: function (data) {
        setUserProfile(data.results[0]);
      },
      error: function (error) {
        console.error(error);
      },
    });
  };

  const renderUserProfile = () => {
    if (Object.keys(userProfile).length > 0) {
      const {
        name,
        picture,
        location,
        phone,
        email,
        dob,
      } = userProfile;
      return (
        <div className="profile">
          <img src={picture.large} alt="Profile" />
          <h3>{`${name.title} ${name.first} ${name.last}`}</h3>
          <p>{`${location.street.number} ${location.street.name}`}</p>
          <p>{`${location.city}, ${location.state} ${location.postcode}`}</p>
          <p>{phone}</p>
          <p>{email}</p>
          <p>{`Age: ${dob.age}`}</p>
        </div>
      );
    }
  };

  return (
    <div className="container">
      <h1>Random User Profile Generator</h1>
      <button onClick={fetchRandomProfile}>Generate Profile</button>
      {renderUserProfile()}
    </div>
  );
}
export default  RandomProfile;
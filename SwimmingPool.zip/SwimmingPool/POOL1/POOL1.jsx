
import React from "react";
import './POOL1.css'
import Pool from "../Pool/Pool";
import Sidebar3 from "../Sidebar3/Sidebar3"



function POOL1() {
    return (
      <div className="POOL">
 
       <Pool/>
       <Sidebar3/>
      
    </div>
    );
  }
  
  export default POOL1;
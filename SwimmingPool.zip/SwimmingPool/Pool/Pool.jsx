
import React from "react";
import "./pool.css";
import swiming from '../assets/swiming.jpg'
function Pool() {
    return (
      <div className="singlepost">
       <div className="singlepostW">

       <img className="Imgpost2"
    src={swiming} alt=""/> 
    <h1 className="postTitle">
        <b>Swimming Pool</b>
    </h1>
             <div className="postInfo">
             <span className="postTitles"><b> Our Policy</b></span>
          
                </div>  

                <p className="PostDesc"> 
    Lorem ipsum, or lipsum as it is sometimes known,
     is dummy text used in laying out print, 
    graphic or web designs. The passage is attributed to an unknown
     typesetter in the 15th century who is thought to have
     scrambled parts of Cicero's De Finibus Bonorum et Malorum
      for use in a type specimen book. It usually begins with
      Lorem ipsum, or lipsum as it is sometimes known,
     is dummy text used in laying out print, 
    graphic or web designs. The passage is attributed to an unknown
     typesetter in the 15th century who is thought to have
     scrambled parts of Cicero's De Finibus Bonorum et Malorum
      for use in a type specimen book. It usually begins with::</p>  
       </div>
    </div>
    );
  }
  
  export default Pool;
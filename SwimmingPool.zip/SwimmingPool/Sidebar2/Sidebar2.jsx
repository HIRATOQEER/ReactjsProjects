import React from "react";
import './Sidebar2.css';
import fb from '../assets/fb.png'
import link1 from '../assets/link1.png'
import twiter from '../assets/twiter.png'
import insta from '../assets/insta.png'
import logo from '../assets/logo.jpeg'

function Sidebar2() {
    return (
    <div className="sidebar">
        <div className="sidebarItems">
        <span className="sidebarTitle"> <b>Gym Information</b></span>
        <img  className="imagp" src={logo} alt=""/>
        <div className="p"> 
        <p> <b> 8 a.m to 11 p.m., Monday-Thursday </b></p>
        </div>
        
        </div>

        <div className="sidebarItems">
            <span className="sidebarTitle"> <b> Membership Category</b></span>
            <ul className="siderbarlist">
                <li className="ListItems"> The Big Box Gym</li>
                <li className="ListItems"> CrossFit</li>
                <li className="ListItems"> Circuit Cardio</li>
                <li className="ListItems"> Circuit Cardio</li>
            
            </ul>
        </div>
        <div className="sidebarItems"> </div>
        <span className="sidebarTitle"> <b>FOLLOW US</b></span>
        <div className="socialcontainer">
        
            <div className="sidebarIcons">
        <p> <img src ={fb} alt =""/>
        <img src ={link1} alt =""/>
        <img src ={twiter} alt =""/>
        <img src ={insta} alt =""/></p>

       </div>
        </div>
    </div>
    );
  }
  
  export default Sidebar2;
  
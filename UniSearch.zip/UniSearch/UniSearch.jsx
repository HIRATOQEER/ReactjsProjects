import React, { useState } from 'react';
import './UniSearch.css';

function GitHubSearch() {
  const [searchInput, setSearchInput] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        `https://api.github.com/search/users?q=${searchInput}`
      );
      const data = await response.json();
      setSearchResults(data.items);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
    <div className='github-search'>
      <h2>GitHub User Search</h2>
      </div>
      <form onSubmit={handleSearch}>
        <input
          type='text'
          placeholder='Enter a GitHub username'
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
        />
        <button type='submit'>Search</button>
      </form>
      <ul>
        {searchResults.map((result) => (
          <li key={result.id}>
            <a href={result.html_url}>
              <img src={result.avatar_url} alt={`${result.login}'s avatar`} />
              <span>{result.login}</span>
            </a>
          </li>
        ))}
      </ul>
      </>
    
  );
}

export default GitHubSearch;
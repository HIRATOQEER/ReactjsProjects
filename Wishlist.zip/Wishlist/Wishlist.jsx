

import React, { useState } from 'react';
import './Wishlist.css';

function Wishlist() {
  const [items, setItems] = useState([]);
  const [itemInput, setItemInput] = useState('');

  const addItem = (e) => {
    e.preventDefault();
    setItems([...items, { name: itemInput, priority: 'Low' }]);
    setItemInput('');
  };

  const removeItem = (item) => {
    setItems(items.filter((i) => i !== item));
  };

  const setPriority = (item, priority) => {
    const index = items.findIndex((i) => i === item);
    const newItems = [...items];
    newItems[index].priority = priority;
    setItems(newItems);
  };

  const moveToTop = (item) => {
    const index = items.findIndex((i) => i === item);
    const newItems = [...items];
    newItems.splice(index, 1);
    newItems.unshift(item);
    setItems(newItems);
  };

  return (
    <>
    <div className='Header'>  <b>My Wish List</b></div>
    <div className='wish-list'>
   
    <form onSubmit={addItem}>
      <input
        type='text'
        placeholder='Add an item'
        value={itemInput}
        onChange={(e) => setItemInput(e.target.value)}
      />
      <button type='submit'>Add</button>
    </form>
    <ul>
      {items.map((item, index) => (
        <li key={index}>
          <div>
            <span>{item.name}</span>
            <button onClick={() => removeItem(item)}>X</button>
          </div>
          <div>
            <select
              value={item.priority}
              onChange={(e) => setPriority(item, e.target.value)}
            >
              <option value='Low'>Low Priority</option>
              <option value='Medium'>Medium Priority</option>
              <option value='High'>High Priority</option>
            </select>
            <button onClick={() => moveToTop(item)}>Move to Top</button>
          </div>
        </li>
      ))}
    </ul>
  </div>
  </>

  );
}

export default Wishlist;
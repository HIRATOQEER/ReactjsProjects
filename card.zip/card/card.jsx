import React from "react";
function card(){

return(

<>
<h3> Hello World</h3>
</>

);

}
export default card;